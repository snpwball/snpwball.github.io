#!/usr/bin/env python3
"""Local opt-in idle hook: instruction stays inside the BSP, app uses the platform API."""
from pathlib import Path
base=Path(__file__).resolve().parents[1]/'.deps/fm1-base'
def append(name,marker,code):
 p=base/name;s=p.read_text()
 if marker not in s:p.write_text(s+'\n'+code+'\n')
append('bsp/chip/fm1_irq.h','fm1_idle_until_irq', '''/* Call only in the main loop with periodic interrupts enabled. */
static inline void fm1_idle_until_irq(void) { __asm__ volatile("idle" ::: "memory"); }''')
append('include/plat.h','void plat_wait_irq(void)', 'void plat_wait_irq(void); /* main-loop wait, not for audio/interrupt callbacks */')
append('device/plat_fm1.c','void plat_wait_irq(void)', 'void plat_wait_irq(void) { fm1_idle_until_irq(); }')
append('host/plat_host.c','void plat_wait_irq(void)', 'void plat_wait_irq(void) {} /* scenario runner advances simulated time */')
