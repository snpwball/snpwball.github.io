#!/usr/bin/env python3
"""Bundle the pinned fm1-base Web MIDI updater with the current, unchanged package."""
import hashlib
import html as html_module
import json
import re
import shutil
import sys
import zipfile
from pathlib import Path
from browser_site import bundle_emulator

APP = Path(__file__).resolve().parents[1]
BASE = APP / ".deps/fm1-base"
sys.path.insert(0, str(BASE / "tools"))
from fm1_install import load_package, STOCK_SHA256  # noqa: E402


def main():
    package = APP / "build/neverhood.fwsc"
    product, _, digest = load_package(package, False)
    if not product.startswith("FM-1_7318"):
        raise SystemExit(f"Unexpected Neverhood identity: {product}")
    stock = APP / "build/recovery/FM-1-V15.fwsc"
    if hashlib.sha256(stock.read_bytes()).hexdigest() != STOCK_SHA256:
        raise SystemExit("The recovery file is not the verified official FM-1 V15")
    libs = []
    for name in ("fm1pkg.js", "fm1ota.js"):
        source = (BASE / "web" / name).read_text()
        source = re.sub(r"^export\s+", "", source, flags=re.M)
        libs.append(re.sub(r"^import .*?;\n", "", source, flags=re.M))
    meta = dict(product=product, pkg=package.name, sha256=digest.hex(),
                stock=stock.name, stockProduct="FM-1_015", stockSha256=STOCK_SHA256)
    out = APP / "build/installer"
    out.mkdir(parents=True, exist_ok=True)
    shutil.copytree(APP / "web/site-assets", out / "site-assets", dirs_exist_ok=True)
    shutil.copyfile(APP / "web/clay-site.css", out / "clay-site.css")
    has_emulator = bundle_emulator(APP, out, digest.hex())
    html = (APP / "web/installer.html").read_text()
    html = html.replace("<!--EMULATOR-->", '<p><a class="play" href="emu/?fw=neverhood&amp;mhz=240">▶ Play in the browser</a></p>' if has_emulator else '')
    html = html.replace("/*LIB*/", "\n".join(libs)).replace("/*META*/", json.dumps(meta))
    html = html.replace("<!--SHA256-->", meta["sha256"])
    shutil.copyfile(package, out / package.name)
    shutil.copyfile(stock, out / stock.name)
    (out / "index.html").write_text(html)
    (out / "manifest.json").write_text(json.dumps(meta, indent=2) + "\n")
    shutil.rmtree(out / "effects", ignore_errors=True)
    (out / "theme-source.json").unlink(missing_ok=True)
    shutil.copyfile(BASE / "LICENSE", out / "MPL-2.0.txt")
    shutil.copyfile(APP / "third_party/tinf/LICENSE", out / "tinf-LICENSE.txt")
    # Corresponding source for the optional MPL platform extension, served with its binary.
    with zipfile.ZipFile(out / "firmware-platform-source.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for name in ("include/plat.h", "device/plat_fm1.c", "device/main_fm1.c", "host/plat_host.c", "bsp/chip/fm1_irq.h", "LICENSE", "CREDITS.md"):
            archive.write(BASE / name, "fm1-base/" + name)
        archive.write(APP / "scripts/ensure-battery-platform.py", "ensure-battery-platform.py")
        archive.write(APP / "scripts/ensure-idle-platform.py", "ensure-idle-platform.py")
        for name in ("tinflate.c", "tinf.h", "LICENSE", "SOURCE.txt"):
            archive.write(APP / "third_party/tinf" / name, "tinf/" + name)
        archive.writestr("SOURCE.txt", "fm1-base: https://github.com/charlesvestal/fm1-base\n"
                         "Pinned revision e35f7e2c6904ff1a3eed10035474c8cf089c0b88 + optional APP_BATTERY patch.\n"
                         "Changes: cached BSP battery read, startup/1s polling, host ADC injection, API declaration.\n")
    instructions = html_module.escape(
        "Install from this page in Chrome or Edge. Connect a charged FM-1 by USB, "
        "press Install Neverhood, and allow MIDI SysEx. Do not unplug while it is writing. "
        "Return to factory V15 from the same page.")
    (out / "instructions.html").write_text(
        '<!doctype html><html lang="en"><meta charset="utf-8"><title>Neverhood — instructions</title>'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        '<style>body{max-width:800px;margin:32px auto;padding:0 20px;font:16px/1.6 system-ui}'
        'pre{white-space:pre-wrap;overflow-wrap:anywhere;font:inherit}</style>'
        '<a href="./">← Installer</a><pre>' + instructions + '</pre></html>')
    with zipfile.ZipFile(out / "updater-source.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for name in ("fm1pkg.js", "fm1ota.js"):
            archive.write(BASE / "web" / name, name)
        archive.write(BASE / "LICENSE", "MPL-2.0.txt")
        archive.write(APP / "web/installer.html", "installer.html")
        archive.write(Path(__file__), "make-installer.py")
    print(f"Ready: {product}, SHA-256 {digest.hex()}")


if __name__ == "__main__":
    main()
